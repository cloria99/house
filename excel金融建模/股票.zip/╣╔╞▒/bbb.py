import tushare as ts  ##导入tushare 模块。
import pandas as pd ##导入pandas模块用于股票数据处理 。

pro_ = ts.pro_api('95cd0d21f1e95f455f2a27afb2cd41cab9b82e803506bb44f909eb4e')##个人的接口TOKEN，在Tushare上注册后可在个人主页上找到。
df = pro_.monthly(ts_code='000333.SZ', start_date='20150101', end_date='20201201', fields='ts_code,trade_date,open,high,low,close,vol,amount')
result=pd.concat([df.set_index('ts_code')], axis=1,join='inner').reset_index()##利用pandas将dailyInfo和dailyBasic的信息合并在一起。
result.to_csv('000333.SZ.csv' , index=True, sep=',', encoding='utf_8_sig', mode='w')##将得到的信息存入csv文件。